local QBCore = exports['qb-core']:GetCoreObject()
local isDead = false
local deathId = 0

local function Notify(msg)
    QBCore.Functions.Notify(msg)
end

local function RevivePlayer()
    local system = Config.AmbulanceSystem

    -- Auto-detect system if set to auto
    if system == 'auto' then
        if GetResourceState('wasabi_ambulance') == 'started' then
            system = 'wasabi'
        else
            system = 'qb'
        end
    end

    if system == 'wasabi' then
        if Config.Debug then print("Reviving via Wasabi Ambulance") end
        TriggerEvent('wasabi_ambulance:revive')
        -- Fallback check for export if event is different in some versions
        if exports['wasabi_ambulance'] then
            pcall(function() exports['wasabi_ambulance']:revivePlayer() end)
        end
    elseif system == 'qb' then
        if Config.Debug then print("Reviving via QBCore Hospital") end
        TriggerEvent('hospital:client:Revive')
        TriggerEvent('qb-ambulancejob:revive')
    end
end

local function StartReviveProgress(currentDeathId)
    local timer = Config.ReviveTimer * 1000
    local label = Config.ProgressBarLabel or "Auto Reviving..."

    if Config.ProgressBar == 'qb' then
        if Config.Debug then print("Starting QB Progress Bar") end
        QBCore.Functions.Progressbar("auto_revive", label, timer, false, true, {
            disableMovement = false,
            disableCarMovement = false,
            disableMouse = false,
            disableCombat = true,
        }, {}, {}, {}, function() -- Done
            if isDead and deathId == currentDeathId then
                RevivePlayer()
                Notify("You have been automatically revived.")
            end
        end, function() -- Cancel
            -- If cancelled handle here if needed
        end)
    elseif Config.ProgressBar == 'ox' then
        if Config.Debug then print("Starting Ox Lib Progress Bar") end
        -- Check if ox_lib is available
        if lib and lib.progressBar then
            if lib.progressBar({
                    duration = timer,
                    label = label,
                    useWhileDead = true,
                    canCancel = false,
                    disable = {
                        move = false,
                        car = false
                    }
                }) then
                if isDead and deathId == currentDeathId then
                    RevivePlayer()
                    Notify("You have been automatically revived.")
                end
            end
        else
            print("^1[MXD-AutoRevive] Ox Lib not found! Check your resources. Fallback to timer.^0")
            SetTimeout(timer, function()
                if isDead and deathId == currentDeathId then
                    RevivePlayer()
                    Notify("You have been automatically revived.")
                end
            end)
        end
    else
        -- Default or 'none' / Fallback
        SetTimeout(timer, function()
            -- Check if still dead and it's the same death instance
            if isDead and deathId == currentDeathId then
                RevivePlayer()
                Notify("You have been automatically revived.")
            end
        end)
    end
end

CreateThread(function()
    while true do
        Wait(Config.CheckInterval)

        local playerData = QBCore.Functions.GetPlayerData()

        -- Ensure player data is valid
        if playerData and playerData.metadata then
            -- Check death status (isdead or inlaststand)
            local dead = playerData.metadata["isdead"] or playerData.metadata["inlaststand"]

            if dead then
                if not isDead then
                    -- Player has just died
                    isDead = true
                    deathId = deathId + 1
                    local currentDeathId = deathId

                    if Config.Debug then print("[MXD-AutoRevive] Player Died. Starting Timer. DeathID:", currentDeathId) end
                    Notify("Auto-Revive in " .. Config.ReviveTimer .. " seconds.")

                    CreateThread(function()
                        StartReviveProgress(currentDeathId)
                    end)
                end
            else
                -- Player is not dead
                if isDead then
                    -- Reset state if player was previously marked as dead
                    isDead = false
                    if Config.Debug then print("[MXD-AutoRevive] Player detected alive. Resetting state.") end
                end
            end
        end
    end
end)

-- Optional: Listen for QBCore player load to sync state immediately
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    local playerData = QBCore.Functions.GetPlayerData()
    local dead = playerData.metadata["isdead"] or playerData.metadata["inlaststand"]
    if dead then
        isDead = true
        deathId = deathId + 1
        -- We don't start timer here to avoid double timer if loop catches it,
        -- or we can rely on the loop to pick it up in 1 second.
        -- Letting the loop handle it is safer to avoid code duplication logic.
        isDead = false -- Let the loop set it to true and start timer.
    end
end)

Config = {}

-- Time in seconds before automatically reviving the player
Config.ReviveTimer = 10

-- Check interval in milliseconds (default 1000ms = 1 second)
Config.CheckInterval = 1000

-- Enable debug prints to console
Config.Debug = false

-- Ambulance System: 'auto', 'qb', 'wasabi'
-- 'auto': Automatically detects if wasabi_ambulance is started, otherwise defaults to qb-ambulancejob
-- 'qb': Forces usage of qb-ambulancejob events
-- 'wasabi': Forces usage of wasabi_ambulance events
Config.AmbulanceSystem = 'auto'

-- Progress Bar System: 'none', 'qb', 'ox'
-- 'none': No progress bar, just a notification and timer
-- 'qb': Uses qb-progressbar
-- 'ox': Uses ox_lib progress circle
Config.ProgressBar = 'qb'

-- Label for the progress bar
Config.ProgressBarLabel = 'Auto Reviving...'

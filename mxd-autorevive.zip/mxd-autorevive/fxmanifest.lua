fx_version 'cerulean'
game 'gta5'

author 'MXD Developments'
description 'Automatic Revive Script for QBCore & Wasabi Ambulance'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client.lua'
}
